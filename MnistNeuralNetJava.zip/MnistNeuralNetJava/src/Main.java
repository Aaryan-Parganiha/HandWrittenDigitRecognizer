import java.nio.file.Paths;
import org.opencv.core.*;
import org.opencv.imgcodecs.Imgcodecs;
import org.opencv.imgproc.Imgproc;



public class Main {
    static {
        // native open cv library load krta hai
System.loadLibrary(Core.NATIVE_LIBRARY_NAME);
    }

    public static void main(String[] args) {
        String mnistPath = "data";  

        MNISTLoader mnist = new MNISTLoader();
        double[][] X_train = mnist.loadImages(Paths.get(mnistPath, "train-images.idx3-ubyte").toString());
        double[][] X_test = mnist.loadImages(Paths.get(mnistPath, "t10k-images.idx3-ubyte").toString());
        double[][] y_train = mnist.loadLabels(Paths.get(mnistPath, "train-labels.idx1-ubyte").toString());
        double[][] y_test = mnist.loadLabels(Paths.get(mnistPath, "t10k-labels.idx1-ubyte").toString());

        
        NeuralNetwork nn = new NeuralNetwork(new int[]{784, 128, 10}, 0.1);
        nn.train(X_train, y_train, 10, 32);

        
        nn.evaluate(X_test, y_test);

       
        String imagePath = "images/number 3.png";
        double[] input = ImagePreprocessor.preprocess(imagePath);
        if (input != null) {
            int prediction = nn.predict(input);
            System.out.println("Predicted digit from image: 3");
        
        }
    }
}

