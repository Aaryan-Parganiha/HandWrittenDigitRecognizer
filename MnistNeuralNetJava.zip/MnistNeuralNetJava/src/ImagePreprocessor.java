import org.opencv.core.*;
import org.opencv.imgcodecs.Imgcodecs;
import org.opencv.imgproc.Imgproc;

public class ImagePreprocessor {

    public static double[] preprocess(String imagePath) {
        Mat img = Imgcodecs.imread(imagePath, Imgcodecs.IMREAD_GRAYSCALE);
        if (img.empty()) {
            System.err.println("Could not load image: " + imagePath);
            return null;
        }
    
       
        Mat resized = new Mat();
        Imgproc.resize(img, resized, new Size(28, 28));

        // Binary Thresholdig and inversion
        Mat thresh = new Mat();
        Imgproc.threshold(resized, thresh, 0, 255, Imgproc.THRESH_BINARY_INV + Imgproc.THRESH_OTSU);

       
        java.util.List<MatOfPoint> contours = new java.util.ArrayList<>();
        Mat hierarchy = new Mat();
        Imgproc.findContours(thresh.clone(), contours, hierarchy, Imgproc.RETR_EXTERNAL, Imgproc.CHAIN_APPROX_SIMPLE);

        Mat finalImg = Mat.zeros(new Size(28, 28), CvType.CV_8UC1);
        if (!contours.isEmpty()) {
            Rect bbox = Imgproc.boundingRect(contours.get(0));
            Mat roi = new Mat(thresh, bbox);
            int x = (28 - roi.width()) / 2;
            int y = (28 - roi.height()) / 2;
            roi.copyTo(finalImg.submat(y, y + roi.height(), x, x + roi.width()));
        } else {
            finalImg = thresh;
        }

       
        finalImg.convertTo(finalImg, CvType.CV_64F);

      
        double[] flat = new double[28 * 28];
        for (int i = 0; i < 28; i++) {
            for (int j = 0; j < 28; j++) {
                flat[i * 28 + j] = finalImg.get(i, j)[0] / 255.0;
            }
        }

        return flat;
        
    }
}
