import java.io.*;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;

public class MNISTLoader {

    public double[][] loadImages(String filePath) {
        try (DataInputStream dis = new DataInputStream(new FileInputStream(filePath))) {
            int magic = dis.readInt();
            int numImages = dis.readInt();
            int rows = dis.readInt();
            int cols = dis.readInt();

            double[][] images = new double[numImages][rows * cols];

            for (int i = 0; i < numImages; i++) {
                for (int j = 0; j < rows * cols; j++) {
                    images[i][j] = dis.readUnsignedByte() / 255.0;
                }
            }
            return images;
        } catch (IOException e) {
            e.printStackTrace();
            return new double[0][0];
        }
    }

    public double[][] loadLabels(String filePath) {
        try (DataInputStream dis = new DataInputStream(new FileInputStream(filePath))) {
            int magic = dis.readInt();
            int numLabels = dis.readInt();

            double[][] labels = new double[numLabels][10];
            for (int i = 0; i < numLabels; i++) {
                int label = dis.readUnsignedByte();
                labels[i][label] = 1.0;
            }
            return labels;
        } catch (IOException e) {
            e.printStackTrace();
            return new double[0][0];
        }
    }
}
