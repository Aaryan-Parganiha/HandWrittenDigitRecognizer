import java.util.Random;

public class NeuralNetwork {
    private int[] layers;
    private double[][][] weights;
    private double[][] biases;
    private double learningRate;
    private Random random;

    
    public NeuralNetwork(int[] layers, double learningRate) {
        this.layers = layers;
        this.learningRate = learningRate;
        this.random = new Random(System.currentTimeMillis()); 
        initializeWeights(); 
    }

    // Method to reinitialize weights and biases
    //public void reset() {
      //  this.random = new Random(System.currentTimeMillis());  // Reinitialize random with a new seed
        //initializeWeights();  // Reinitialize weights and biases to random values
    //}

    //Xavier
    private void initializeWeights() {
        weights = new double[layers.length - 1][][]; 
        biases = new double[layers.length - 1][];     

        for (int i = 0; i < layers.length - 1; i++) {
            weights[i] = new double[layers[i]][layers[i + 1]];
            biases[i] = new double[layers[i + 1]];

            for (int j = 0; j < layers[i]; j++) {
                for (int k = 0; k < layers[i + 1]; k++) {
                    weights[i][j][k] = random.nextGaussian() * Math.sqrt(2.0 / layers[i]); // Xavier initialization
                }
            }
        }
    }

    // Forward pass
    public double[][] forward(double[] input) {
        double[][] activations = new double[layers.length][];
        activations[0] = input;

        for (int i = 1; i < layers.length; i++) {
            activations[i] = new double[layers[i]];

            for (int j = 0; j < layers[i]; j++) {
                double sum = biases[i - 1][j];
                for (int k = 0; k < layers[i - 1]; k++) {
                    sum += activations[i - 1][k] * weights[i - 1][k][j];
                }
                if (i == layers.length - 1) {
                    activations[i][j] = softmaxDummy(sum);  
                } else {
                    activations[i][j] = relu(sum);
                }
            }
        }

        
        activations[activations.length - 1] = softmax(activations[activations.length - 1]);

        return activations;
    }

    // Training 
    public void train(double[][] X, double[][] y, int epochs, int batchSize) {
        for (int epoch = 0; epoch < epochs; epoch++) {
            for (int i = 0; i < X.length; i += batchSize) {
                int end = Math.min(i + batchSize, X.length);
                updateBatch(X, y, i, end);
            }

            double loss = computeLoss(X, y);
            double acc = evaluate(X, y);
            System.out.printf("Epoch %d/%d - Loss: %.4f - Accuracy: %.4f%n", epoch + 1, epochs, loss, acc);
        }
    }

    // Update weights using backpropagation
    private void updateBatch(double[][] X, double[][] y, int start, int end) {
        double[][][] weightGradientsSum = new double[weights.length][][];  
        double[][] biasGradientsSum = new double[biases.length][];  

        for (int i = 0; i < weights.length; i++) {
            weightGradientsSum[i] = new double[weights[i].length][weights[i][0].length];
            biasGradientsSum[i] = new double[biases[i].length];
        }

        for (int i = start; i < end; i++) {
            double[][] activations = forward(X[i]);
            double[][] deltas = new double[layers.length][];

            
            deltas[deltas.length - 1] = new double[layers[layers.length - 1]];
            for (int j = 0; j < layers[layers.length - 1]; j++) {
                deltas[deltas.length - 1][j] = activations[activations.length - 1][j] - y[i][j];
            }

            // Backpropagate errors
            for (int l = layers.length - 2; l > 0; l--) {
                deltas[l] = new double[layers[l]];
                for (int j = 0; j < layers[l]; j++) {
                    double error = 0.0;
                    for (int k = 0; k < layers[l + 1]; k++) {
                        error += deltas[l + 1][k] * weights[l][j][k];
                    }
                    deltas[l][j] = error * reluDerivative(activations[l][j]);
                }
            }

            // Compute gradients
            for (int l = 0; l < weights.length; l++) {
                for (int j = 0; j < weights[l].length; j++) {
                    for (int k = 0; k < weights[l][j].length; k++) {
                        weightGradientsSum[l][j][k] += activations[l][j] * deltas[l + 1][k];
                    }
                }
                for (int j = 0; j < biases[l].length; j++) {
                    biasGradientsSum[l][j] += deltas[l + 1][j];
                }
            }
        }

        // Update weights and biases
        for (int l = 0; l < weights.length; l++) {
            for (int j = 0; j < weights[l].length; j++) {
                for (int k = 0; k < weights[l][j].length; k++) {
                    weights[l][j][k] -= learningRate * weightGradientsSum[l][j][k] / (end - start);
                }
            }
            for (int j = 0; j < biases[l].length; j++) {
                biases[l][j] -= learningRate * biasGradientsSum[l][j] / (end - start);
            }
        }
    }

    // Compute loss 
    public double computeLoss(double[][] X, double[][] y) {
        double loss = 0.0;
        for (int i = 0; i < X.length; i++) {
            double[][] output = forward(X[i]);
            double[] predicted = output[output.length - 1];

            for (int j = 0; j < y[i].length; j++) {
                loss -= y[i][j] * Math.log(Math.max(predicted[j], 1e-15));
            }
        }
        return loss / X.length;
    }

    // Evaluate accuracy
    public double evaluate(double[][] X, double[][] y) {
        int correct = 0;
        for (int i = 0; i < X.length; i++) {
            double[][] output = forward(X[i]);
            int predictedLabel = argMax(output[output.length - 1]);
            int trueLabel = argMax(y[i]);

            if (predictedLabel == trueLabel) {
                correct++;
            }
        }
        return (double) correct / X.length;
    }

    // Prediction
    public int predict(double[] X) {
        double[][] output = forward(X);
        return argMax(output[output.length - 1]);
    }

    // ReLU activation function
    private double relu(double x) {
        return Math.max(0, x);
    }

  
    private double reluDerivative(double x) {
        return x > 0 ? 1 : 0;
    }

   
    private double softmaxDummy(double x) {
        return x; 
    }

    // Softmax function
    private double[] softmax(double[] z) {
        double max = Double.NEGATIVE_INFINITY;
        for (double v : z) {
            if (v > max) max = v;
        }

        double sum = 0.0;
        double[] exp = new double[z.length];
        for (int i = 0; i < z.length; i++) {
            exp[i] = Math.exp(z[i] - max);
            sum += exp[i];
        }

        double[] output = new double[z.length];
        for (int i = 0; i < z.length; i++) {
            output[i] = exp[i] / sum;
        }
        return output;
    }

  
    private int argMax(double[] array) {
        int maxIndex = 0;
        double max = array[0];
        for (int i = 1; i < array.length; i++) {
            if (array[i] > max) {
                max = array[i];
                maxIndex = i;
            }
        }
        return maxIndex;
        
    }
}       
